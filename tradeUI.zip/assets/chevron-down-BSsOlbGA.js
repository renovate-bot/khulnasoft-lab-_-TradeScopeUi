import{o as e,c as o,a as t}from"./index-rNerOcjc.js";const n={viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"},c=t("path",{fill:"currentColor",d:"M7.41 8.58L12 13.17l4.59-4.59L18 10l-6 6l-6-6z"},null,-1),s=[c];function r(_,l){return e(),o("svg",n,[...s])}const i={name:"mdi-chevron-down",render:r};export{i as _};
//# sourceMappingURL=chevron-down-BSsOlbGA.js.map
