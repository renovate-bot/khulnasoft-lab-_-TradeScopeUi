import{h as t,K as c,bi as m,aN as o}from"./installCanvasRenderer-2I4tQ6Q_.js";function S(a,e,n){e=t(e)&&{coordDimensions:e}||c({encodeDefine:a.getEncode()},e);var r=a.getSource(),s=m(r,e).dimensions,i=new o(s,a);return i.initData(r,n),i}export{S as c};
//# sourceMappingURL=createSeriesDataSimply-CePoxYQG.js.map
