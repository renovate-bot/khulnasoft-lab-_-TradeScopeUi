import{_ as c,c as t,b as o,w as _,S as a,o as s,bc as r}from"./index-rNerOcjc.js";const d={},i={class:"container"};function l(p,f){const e=r,n=a;return s(),t("div",i,[o(n,{header:"Tradescope bot Login"},{default:_(()=>[o(e,{ref:"loginForm"},null,512)]),_:1})])}const u=c(d,[["render",l],["__scopeId","data-v-ba9d1b78"]]);export{u as default};
//# sourceMappingURL=LoginView-IXKK8GQr.js.map
